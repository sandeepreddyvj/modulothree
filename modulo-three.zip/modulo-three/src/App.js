import './App.css';
import FiniteAutomation from './components/FiniteAutomation';
import ModThreeAutomation from './components/ModThreeAutomation';

function App() {
  return (
    <div className="App">
      <FiniteAutomation/>
      <ModThreeAutomation/>
    </div>
  );
}

export default App;
