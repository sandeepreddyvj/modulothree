import { useState } from 'react';

export const useFiniteAutomaton = (Q, Σ, q0, F, δ) => {
  const [currentState, setCurrentState] = useState(q0);

  const transition = (input) => {
    if (!Σ.includes(input)) {
      console.error(`Input ${input} not in alphabet`);
      return;
    }
    if (!Q.includes(currentState)) {
      console.error(`Current state ${currentState} not in set of states`);
      return;
    }
    const nextState = δ[currentState][input];
    if (!nextState) {
      console.error(`Transition for state ${currentState} and input ${input} not defined`);
      return;
    }
    setCurrentState(nextState);
  };

  const reset = () => {
    setCurrentState(q0);
  };

  const getOutPutValue = () => {
    return F[currentState];
  };

  return { currentState, transition, reset, getOutPutValue };
};

const ModThreeAutomation = () => {
  const Q = ['S0', 'S1', 'S2'];
  const Σ = ['0', '1'];
  const q0 = 'S0';
  const F = { S0: '0', S1: '1', S2: '2' };
  const δ = {
    S0: { '0': 'S0', '1': 'S1' },
    S1: { '0': 'S2', '1': 'S0' },
    S2: { '0': 'S1', '1': 'S2' },
  };

  const { currentState, transition, reset, getOutPutValue } = useFiniteAutomaton(Q, Σ, q0, F, δ);

  return (
    <div>
      <h2>Mod-Three Machine</h2>
      <p>Current state: {currentState}</p>
      <button onClick={() => transition('0')}>Input 0</button>
      <button onClick={() => transition('1')}>Input 1</button>
      <button onClick={reset}>Reset</button>
      <p>output value: {getOutPutValue()}</p>
    </div>
  );
};

export default ModThreeAutomation;
