import React, { useState } from 'react';

const FiniteAutomation = () => {
    const [number, setNumber] = useState('');
    
    // Define the initial state
    const initialState = 'S0';

    const outputValues = { S0: '0', S1: '1', S2: '2' };
    // Define the transition function
    const transitions = {
        S0: { '0': 'S0', '1': 'S1' },
        S1: { '0': 'S2', '1': 'S0' },
        S2: { '0': 'S1', '1': 'S2' }
    };

    // Initialize state variables
    const [output, setOutput] = useState(null);

    // Define the processInput function
    const processInput = () => {
        let inputString = number.toString();;
        if(inputString){
            let currentState = initialState;
            for (let input of inputString) {
                currentState = transitions[currentState][input] || currentState;
            }
            setOutput(outputValues[currentState]);

        }
    };

    return (
        <div>
            <h2>Mod-Three FSM</h2>
            <input type='number' placeholder='Enter the number' value={number} onChange={(e) => setNumber(e.target.value)} />
            <button onClick={processInput}>Process Input</button>
            {output && <p>Output value: {output}</p>}
        </div>
    );
};

export default FiniteAutomation;

