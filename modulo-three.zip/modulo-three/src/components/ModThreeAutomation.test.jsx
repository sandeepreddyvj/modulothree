import { render, fireEvent } from '@testing-library/react';
import ModThreeAutomation from './ModThreeAutomation';

describe('useFiniteAutomaton', () => {
    test('initial state should be S0', () => {
    const { getByText } = render(<ModThreeAutomation />);
    const currentState = getByText(/Current state/i);
    expect(currentState.textContent).toContain('S0');
    });

    test('transition with input 0 should change state correctly', () => {
    const { getByText } = render(<ModThreeAutomation />);
    const input0Button = getByText(/Input 0/i);
    fireEvent.click(input0Button);
    const currentState = getByText(/Current state/i);
    expect(currentState.textContent).toContain('S0');
    });

    test('transition with input 1 should change state correctly', () => {
    const { getByText } = render(<ModThreeAutomation />);
    const input1Button = getByText(/Input 1/i);
    fireEvent.click(input1Button);
    const currentState = getByText(/Current state/i);
    expect(currentState.textContent).toContain('S1');
    });

    test('reset should change state to initial state', () => {
    const { getByText } = render(<ModThreeAutomation />);
    const input1Button = getByText(/Input 1/i);
    fireEvent.click(input1Button);
    const resetButton = getByText(/Reset/i);
    fireEvent.click(resetButton);
    const currentState = getByText(/Current state/i);
    expect(currentState.textContent).toContain('S0');
    });
});


