import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import FiniteAutomation from './FiniteAutomation';


describe('FiniteAutomation Component', () => {
  test('renders input field and process button', () => {
    const { getByPlaceholderText, getByText } = render(<FiniteAutomation />);
    const inputField = getByPlaceholderText('Enter the number');
    const processButton = getByText('Process Input');
    expect(inputField).toBeInTheDocument();
    expect(processButton).toBeInTheDocument();
  });

  test('processes input correctly and displays output', () => {
    const { getByPlaceholderText, getByText } = render(<FiniteAutomation />);
    const inputField = getByPlaceholderText('Enter the number');
    const processButton = getByText('Process Input');
    fireEvent.change(inputField, { target: { value: '1010' } });
    fireEvent.click(processButton);
    const outputValue = getByText('Output value: 1');
    expect(outputValue).toBeInTheDocument();
  });

  test('handles invalid input correctly', () => {
    const { getByPlaceholderText, getByText, queryByText } = render(<FiniteAutomation />);
    const inputField = getByPlaceholderText('Enter the number');
    const processButton = getByText('Process Input');
    fireEvent.change(inputField, { target: { value: '1020' } }); // Invalid input
    fireEvent.click(processButton);
    const outputValue = queryByText('Output value:'); // No output displayed
    expect(outputValue).toBeNull();
  });
});
